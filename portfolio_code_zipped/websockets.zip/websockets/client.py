# client_sender.py
import asyncio
import websockets

async def send():
    async with websockets.connect("ws://localhost:8765") as websocket:
        while True:
            message = input("Enter message to send: ")
            await websocket.send(message)
            reply = await websocket.recv()
            print(f"Received from server: {reply}")

if __name__ == "__main__":
    asyncio.get_event_loop().run_until_complete(send())
