import asyncio
import websockets

async def echo(websocket, path):
    async for message in websocket:
        print("Received:", message)  # Print received message
        await websocket.send("Received: " + message)

start_server = websockets.serve(echo, "localhost", 8765)

try:
    asyncio.get_event_loop().run_until_complete(start_server)
    asyncio.get_event_loop().run_forever()
except Exception as e:
    print(f"Error: {e}")


